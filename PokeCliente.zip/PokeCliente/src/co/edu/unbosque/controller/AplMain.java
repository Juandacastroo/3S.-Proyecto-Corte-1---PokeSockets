package co.edu.unbosque.controller;

public class AplMain {

	public static void main(String[] args) {
		
Cliente cliente= new Cliente();
HiloClienteEntrenador  hilo_entrenador= new HiloClienteEntrenador(null, null);

cliente.iniciarCliente();
hilo_entrenador.run();


	}

}
