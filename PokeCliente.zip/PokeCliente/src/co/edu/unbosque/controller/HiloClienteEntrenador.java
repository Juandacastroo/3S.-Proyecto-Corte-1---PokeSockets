package co.edu.unbosque.controller;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class HiloClienteEntrenador extends Thread {

	private DataInputStream in;
	private DataOutputStream out;

	public HiloClienteEntrenador(DataInputStream in, DataOutputStream out) {
		this.in = in;
		this.out = out;
	}

	@Override
	public void run() {

		Scanner sc = new Scanner(System.in);

		int opcion = 0;
		String mensaje;

		boolean salir = false;

		while (!false) {
			try {
				System.out.println("\n");
				System.out.println("Digite la opci�n que desea realizar: ");
				System.out.println("1. Agregar pokemon   ");
				System.out.println("2. Intercambiar pokemon ");
				System.out.println("3. Mostrar cajas ");
				System.out.println("4. Mostrar blosillo ");
				System.out.println("5. Liberaci�n de pokemon ");
				System.out.println("\n");

				opcion = sc.nextInt();
				out.writeInt(opcion);

				switch (opcion) {
				case 1:
					System.out.println("Digite el nombre del pok�mon:");
					String nombre_pokemon = sc.next();
					out.writeUTF(nombre_pokemon);

					System.out.println("Digite la defensa del pok�mon:");
					int defensa = sc.nextInt();
					out.writeInt(defensa);

					System.out.println("Digite la defensa esp. del pok�mon:");
					int defensa_esp = sc.nextInt();
					out.writeInt(defensa_esp);

					System.out.println("Digite el ataque del pok�mon:");
					int ataque = sc.nextInt();
					out.writeInt(ataque);

					System.out.println("Digite el ataque especial del pok�mon:");
					int ataque_esp = sc.nextInt();
					out.writeInt(ataque_esp);

					System.out.println("Digite la velocidad del pok�mon:");
					int velocidad = sc.nextInt();
					out.writeInt(velocidad);

					System.out.println("Digite el nivel del pok�mon:");
					int nivel = sc.nextInt();
					out.writeInt(nivel);

					System.out.println(
							"\n Digite 1: para guardar en Caja 1 \n Digite 2: para guardar en caja 2 \n Digite 3: para guarfar en caja 3 \n Digite 4: para guardar en Bolsillo  ");
					int opcion_caja = sc.nextInt();
					out.writeInt(opcion_caja);

					break;
				case 2:

					System.out.println("Digite el nombre del pok�mon que quiere sacar de la caja:");
					String nombrepoke_intercambio_caja = sc.next();
					out.writeUTF(nombrepoke_intercambio_caja);

					System.out.println("Digite el nombre del pok�mon que quiere sacar del bolsillo:");
					String nombrepoke_intercambio_bolsillo = sc.next();
					out.writeUTF(nombrepoke_intercambio_bolsillo);

					System.out.println("Elija la caja para el intercambio de pok�mones (1,2,3): ");
					int intercambio_poke = sc.nextInt();
					out.writeInt(intercambio_poke);

				case 3:
					System.out.println("Que caja quiere ver (1,2,3):");
					int opcaja = sc.nextInt();
					out.writeInt(opcaja);
					String poke_mostrar_1 = in.readUTF();
					System.out.println(poke_mostrar_1);

					break;

				case 4:
					
						String[] lista_bolsillo = new String[6];

						String poke_bolsillo1 = in.readUTF();
						lista_bolsillo[0] = poke_bolsillo1;

						if (lista_bolsillo[0] != null) {
							System.out.println(poke_bolsillo1);

						} else {
							String vacio1 = in.readUTF();
							System.out.println(vacio1);
						}

					

					String poke_bolsillo2 = in.readUTF();
					lista_bolsillo[1] = poke_bolsillo2;

					if (lista_bolsillo[1] != null) {
						System.out.println(poke_bolsillo2);

					} else {
						String vacio2 = in.readUTF();
					}

					String poke_bolsillo3 = in.readUTF();
					lista_bolsillo[2] = poke_bolsillo3;

					if (lista_bolsillo[2] != null) {
						System.out.println(poke_bolsillo3);

					} else {
						String vacio3 = in.readUTF();
					}
//
					String poke_bolsillo4 = in.readUTF();
					lista_bolsillo[3] = poke_bolsillo4;

					if (lista_bolsillo[3] != null) {
						System.out.println(poke_bolsillo4);

					} else {
						String vacio4 = in.readUTF();
					}

					String poke_bolsillo5 = in.readUTF();
					lista_bolsillo[4] = poke_bolsillo5;

					if (lista_bolsillo[4] != null) {
						System.out.println(poke_bolsillo5);

					} else {
						String vacio5 = in.readUTF();
					}

					String poke_bolsillo6 = in.readUTF();
					lista_bolsillo[5] = poke_bolsillo6;

					if (lista_bolsillo[5] != null) {
						System.out.println(poke_bolsillo6);

					} else {
						String vacio6 = in.readUTF();
					}

					break;

				case 5:

					System.out.println("Digite el nombre del pok�mon que deseea eliminar:");
					String nombre_pokemonn = sc.next();
					out.writeUTF(nombre_pokemonn);

					System.out.println("Elija la caja de la cual quiere liberar a su pok�mon: \n 1-2-3.");
					int opcioncajael = sc.nextInt();
					out.writeInt(opcioncajael);

					break;

				default:

					mensaje = in.readUTF();

				}
			} catch (IOException ex) {
				Logger.getLogger(HiloClienteEntrenador.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
	}
}
