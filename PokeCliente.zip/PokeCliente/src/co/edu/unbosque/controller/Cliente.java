package co.edu.unbosque.controller;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Cliente {

    
	public void iniciarCliente() {
		
	
        
        try {
            Scanner sn = new Scanner(System.in);
            sn.useDelimiter("\n");
            
            // se pone la direcci�n ip y el puerto que se puso en el servidor para que se establezca la conexi�n  
            Socket sc = new Socket("127.0.0.1", 5000);
            
            // entrada y salida de informaci�n 
            DataInputStream in = new DataInputStream(sc.getInputStream());
            DataOutputStream out = new DataOutputStream(sc.getOutputStream());
            

            
         // Pido al cliente la opcion que quiera realizar
			System.out.println("Indica el nombre del entrenador: ");
            
            // Escribe el nombre y se lo manda al servidor
            
            String  nombre_entrenador= sn.next();
           
            out.writeUTF(nombre_entrenador);
            
            
            

    
            
            // ejecutamos el hilo
            HiloClienteEntrenador hilo = new HiloClienteEntrenador(in, out);
            hilo.start();
            hilo.join();
            
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }

	} 
        
    
    
}