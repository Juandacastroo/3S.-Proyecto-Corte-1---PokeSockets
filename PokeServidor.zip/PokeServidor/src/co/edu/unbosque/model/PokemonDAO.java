package co.edu.unbosque.model;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class PokemonDAO {

	public ArrayList<PokemonDTO> caja_numero_uno = new ArrayList<PokemonDTO>();
	public ArrayList<PokemonDTO> caja_numero_dos = new ArrayList<PokemonDTO>();
	public ArrayList<PokemonDTO> caja_numero_tres = new ArrayList<PokemonDTO>();
	File f = new File("poke.txt");
	File f1 = new File("poke1.txt");
	File f2 = new File("poke2.txt");
	File f3 = new File("poke3.txt");

	public ArrayList<PokemonDTO> bolsillo = new ArrayList<PokemonDTO>();

//	public PokemonDTO[] bolsillo = new PokemonDTO[5];

	public void guardarPokemonCaja1(String entrenador, String nombre_pokemon, int ps, int suma, int ataque, int defensa,
			int ataque_especial, int defensa_especial, int velocidad, long promedio, long desviacion_tipica) {

		PokemonDTO pokemonDTO1 = new PokemonDTO(entrenador, nombre_pokemon, ps, suma, ataque, defensa, ataque_especial,
				defensa_especial, velocidad, promedio, desviacion_tipica);

		caja_numero_dos.add(pokemonDTO1);

	}

	public void guardarPokemonCaja2(String entrenador, String nombre_pokemon, int ps, int suma, int ataque, int defensa,
			int ataque_especial, int defensa_especial, int velocidad, long promedio, long desviacion_tipica) {

		PokemonDTO pokemonDTO2 = new PokemonDTO(entrenador, nombre_pokemon, ps, suma, ataque, defensa, ataque_especial,
				defensa_especial, velocidad, promedio, desviacion_tipica);

		caja_numero_dos.add(pokemonDTO2);

	}

	public void guardarPokemonCaja3(String entrenador, String nombre_pokemon, int ps, int suma, int ataque, int defensa,
			int ataque_especial, int defensa_especial, int velocidad, long promedio, long desviacion_tipica) {

		PokemonDTO pokemonDTO3 = new PokemonDTO(entrenador, nombre_pokemon, ps, suma, ataque, defensa, ataque_especial,
				defensa_especial, velocidad, promedio, desviacion_tipica);

		caja_numero_dos.add(pokemonDTO3);

	}

	public void guardarPokemonBolsillo(String entrenador, String nombre_pokemon, int ps, int suma, int ataque,
			int defensa, int ataque_especial, int defensa_especial, int velocidad, long promedio,
			long desviacion_tipica) {

		PokemonDTO pokemonDTOb = new PokemonDTO(entrenador, nombre_pokemon, ps, suma, ataque, defensa, ataque_especial,
				defensa_especial, velocidad, promedio, desviacion_tipica);
		bolsillo.add(pokemonDTOb);
	}

	public void intercambiarPokemonCajaBolsillo(String nombrepoke_intercambio) {

		for (int i = 0; i < caja_numero_uno.size(); i++) {
			if (nombrepoke_intercambio.equals(caja_numero_uno.get(i).getNombre_pokemon())) {

				String nombre = caja_numero_uno.get(i).getNombre_pokemon();
				String entre = caja_numero_uno.get(i).getEntrenador();
				int ataquee = caja_numero_uno.get(i).getAtaque();
				int aespe = caja_numero_uno.get(i).getAtaque_especial();
				int def = caja_numero_uno.get(i).getDefensa();
				int defesp = caja_numero_uno.get(i).getDefensa_especial();
				int pss = caja_numero_uno.get(i).getPs();
				int sumaa = caja_numero_uno.get(i).getSuma();
				int veloc = caja_numero_uno.get(i).getVelocidad();
				long prome = caja_numero_uno.get(i).getPromedio();
				long destipi = caja_numero_uno.get(i).getDesviacion_tipica();

				PokemonDTO pok = new PokemonDTO(nombre, entre, pss, sumaa, ataquee, def, aespe, defesp, veloc, prome,
						destipi);
				bolsillo.add(pok);

				System.out.println("pok�mon" + caja_numero_uno.get(i).getNombre_pokemon() + " eliminado.   ");
				caja_numero_uno.remove(i);

				break;
			} else {
				System.out.println("Pok�mon no encontrado");

			}

		}

	}

	public void intercambiarPokemonBolsilloCaja(String nombrepoke_intercambio_bolsillo) {
		for (int i = 0; i < bolsillo.size(); i++) {

			if (nombrepoke_intercambio_bolsillo.equals(bolsillo.get(i).getNombre_pokemon())) {

				String nombre = bolsillo.get(i).getNombre_pokemon();
				String entre = bolsillo.get(i).getEntrenador();
				int ataquee = bolsillo.get(i).getAtaque();
				int aespe = bolsillo.get(i).getAtaque_especial();
				int def = bolsillo.get(i).getDefensa();
				int defesp = bolsillo.get(i).getDefensa_especial();
				int pss = bolsillo.get(i).getPs();
				int sumaa = bolsillo.get(i).getSuma();
				int veloc = bolsillo.get(i).getVelocidad();
				long prome = bolsillo.get(i).getPromedio();
				long destipi = bolsillo.get(i).getDesviacion_tipica();

				PokemonDTO pok = new PokemonDTO(nombre, entre, pss, sumaa, ataquee, def, aespe, defesp, veloc, prome,
						destipi);
				caja_numero_uno.add(pok);

				System.out.println("pok�mon" + bolsillo.get(i).getNombre_pokemon() + " eliminado.   ");
				bolsillo.remove(i);

			} else {
				System.out.println("Pok�mon no encontrado");

			}
		}
	}

	public boolean liberacionDePokemonCaja1(String nombre_pokemon) {

		java.util.Date hora = new java.util.Date();
		for (int i = 0; i < caja_numero_uno.size(); i++) {
			if (nombre_pokemon.equals(caja_numero_uno.get(i).getNombre_pokemon())) {

				System.out.println("Vehiculo " + caja_numero_uno.get(i).getNombre_pokemon() + " eliminado.   " + hora);
				caja_numero_uno.remove(i);
				break;
			} else {
				System.out.println("Placa no encontrada");

			}
		}

		return true;

	}

	public boolean liberacionDePokemonCaja2(String nombre_pokemon) {

		java.util.Date hora = new java.util.Date();
		for (int i = 0; i < caja_numero_dos.size(); i++) {
			if (nombre_pokemon.equals(caja_numero_dos.get(i).getNombre_pokemon())) {

				System.out.println("Vehiculo " + caja_numero_dos.get(i).getNombre_pokemon() + " eliminado.   " + hora);
				caja_numero_dos.remove(i);
				break;
			} else {
				System.out.println("Placa no encontrada");

			}
		}

		return true;

	}

	public boolean liberacionDePokemonCaja3(String nombre_pokemon) {

		java.util.Date hora = new java.util.Date();
		for (int i = 0; i < caja_numero_tres.size(); i++) {
			if (nombre_pokemon.equals(caja_numero_tres.get(i).getNombre_pokemon())) {

				System.out.println("Vehiculo " + caja_numero_tres.get(i).getNombre_pokemon() + " eliminado.   " + hora);
				caja_numero_tres.remove(i);
				break;
			} else {
				System.out.println("Placa no encontrada");

			}
		}

		return true;

	}

	public void escribirDatosCaja1(File f1, String entrenador, String nombre_pokemon, int ps, int suma, int ataque,
			int defensa, int ataque_especial, int defensa_especial, int velocidad, long promedio,
			long desviacion_tipica) throws IOException {
		FileWriter fw = new FileWriter(f1, true);
		fw.write(" Entrenador=" + entrenador + ", Nombre del pokemon=" + nombre_pokemon + ", ps=" + ps + ", Suma="
				+ suma + ", Ataque=" + ataque + ", Defensa=" + defensa + ", Ataque especial=" + ataque_especial
				+ ", Defensa especial=" + defensa_especial + ", Velocidad=" + velocidad + ", Promedio=" + promedio
				+ ", Desviacion tipica=" + desviacion_tipica + "\r\n");
		fw.close();

	}

	public void escribirDatosCaja2(File f2, String entrenador, String nombre_pokemon, int ps, int suma, int ataque,
			int defensa, int ataque_especial, int defensa_especial, int velocidad, long promedio,
			long desviacion_tipica) throws IOException {
		FileWriter fw = new FileWriter(f2, true);
		fw.write(" Entrenador=" + entrenador + ", Nombre del pokemon=" + nombre_pokemon + ", ps=" + ps + ", Suma="
				+ suma + ", Ataque=" + ataque + ", Defensa=" + defensa + ", Ataque especial=" + ataque_especial
				+ ", Defensa especial=" + defensa_especial + ", Velocidad=" + velocidad + ", Promedio=" + promedio
				+ ", Desviacion tipica=" + desviacion_tipica + "\r\n");
		fw.close();

	}

	public void escribirDatosCaja3(File f3, String entrenador, String nombre_pokemon, int ps, int suma, int ataque,
			int defensa, int ataque_especial, int defensa_especial, int velocidad, long promedio,
			long desviacion_tipica) throws IOException {
		FileWriter fw = new FileWriter(f3, true);
		fw.write(" Entrenador=" + entrenador + ", Nombre del pokemon=" + nombre_pokemon + ", ps=" + ps + ", Suma="
				+ suma + ", Ataque=" + ataque + ", Defensa=" + defensa + ", Ataque especial=" + ataque_especial
				+ ", Defensa especial=" + defensa_especial + ", Velocidad=" + velocidad + ", Promedio=" + promedio
				+ ", Desviacion tipica=" + desviacion_tipica + "\r\n");
		fw.close();

	}

	public void escribirDatosGeneral(File f, String entrenador, String nombre_pokemon, int ps, int suma, int ataque,
			int defensa, int ataque_especial, int defensa_especial, int velocidad, long promedio,
			long desviacion_tipica) throws IOException {
		FileWriter fw = new FileWriter(f, true);
		fw.write(" Entrenador=" + entrenador + ", Nombre del pokemon=" + nombre_pokemon + ", ps=" + ps + ", Suma="
				+ suma + ", Ataque=" + ataque + ", Defensa=" + defensa + ", Ataque especial=" + ataque_especial
				+ ", Defensa especial=" + defensa_especial + ", Velocidad=" + velocidad + ", Promedio=" + promedio
				+ ", Desviacion tipica=" + desviacion_tipica + "\r\n");
		fw.close();

	}

	public void borarCaja1(String nombre_pokemon, File f1) {
		try {

			Scanner lector = new Scanner(f1);

			while (lector.hasNextLine()) {
				String linea = lector.nextLine();

				if (linea.contains(nombre_pokemon)) {

					linea.replaceAll(nombre_pokemon, linea);

				}
			}

			lector.close();
		} catch (Exception e) {

			System.out.println("La palabra no esta en el diccionario : " + e.getMessage());

		}
	}

	

	public ArrayList<PokemonDTO> getCaja_numero_uno() {
		return caja_numero_uno;
	}

	public void setCaja_numero_uno(ArrayList<PokemonDTO> caja_numero_uno) {
		this.caja_numero_uno = caja_numero_uno;
	}

	public ArrayList<PokemonDTO> getCaja_numero_dos() {
		return caja_numero_dos;
	}

	public void setCaja_numero_dos(ArrayList<PokemonDTO> caja_numero_dos) {
		this.caja_numero_dos = caja_numero_dos;
	}

	public ArrayList<PokemonDTO> getCaja_numero_tres() {
		return caja_numero_tres;
	}

	public void setCaja_numero_tres(ArrayList<PokemonDTO> caja_numero_tres) {
		this.caja_numero_tres = caja_numero_tres;
	}

	public ArrayList<PokemonDTO> getBolsillo() {
		return bolsillo;
	}

	public void setBolsillo(ArrayList<PokemonDTO> bolsillo) {
		this.bolsillo = bolsillo;
	}

//	public PokemonDTO[] getBolsillo() {
//		return bolsillo;
//	}
//	public void setBolsillo(PokemonDTO[] bolsillo) {
//		this.bolsillo = bolsillo;
//	}

}
