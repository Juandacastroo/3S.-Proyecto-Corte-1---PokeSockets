package co.edu.unbosque.model;

public class PokemonDTO {
	private String entrenador;
	private String nombre_pokemon;
	private int ps;
	private int suma;
	private int ataque;
	private int defensa;
	private int ataque_especial;
	private int defensa_especial;
	private int velocidad;
	private long promedio;
	private long  desviacion_tipica;
	
	
	public PokemonDTO(String entrenador, String nombre_pokemon, int ps, int suma, int ataque, int defensa,
			int ataque_especial, int defensa_especial, int velocidad, long promedio, long desviacion_tipica) {
		super();
		this.entrenador = entrenador;
		this.nombre_pokemon = nombre_pokemon;
		this.ps = ps;
		this.suma = suma;
		this.ataque = ataque;
		this.defensa = defensa;
		this.ataque_especial = ataque_especial;
		this.defensa_especial = defensa_especial;
		this.velocidad = velocidad;
		this.promedio = promedio;
		this.desviacion_tipica = desviacion_tipica;
	}


	public String getEntrenador() {
		return entrenador;
	}


	public void setEntrenador(String entrenador) {
		this.entrenador = entrenador;
	}


	public String getNombre_pokemon() {
		return nombre_pokemon;
	}


	public void setNombre_pokemon(String nombre_pokemon) {
		this.nombre_pokemon = nombre_pokemon;
	}


	public int getPs() {
		return ps;
	}


	public void setPs(int ps) {
		this.ps = ps;
	}


	public int getSuma() {
		return suma;
	}


	public void setSuma(int suma) {
		this.suma = suma;
	}


	public int getAtaque() {
		return ataque;
	}


	public void setAtaque(int ataque) {
		this.ataque = ataque;
	}


	public int getDefensa() {
		return defensa;
	}


	public void setDefensa(int defensa) {
		this.defensa = defensa;
	}


	public int getAtaque_especial() {
		return ataque_especial;
	}


	public void setAtaque_especial(int ataque_especial) {
		this.ataque_especial = ataque_especial;
	}


	public int getDefensa_especial() {
		return defensa_especial;
	}


	public void setDefensa_especial(int defensa_especial) {
		this.defensa_especial = defensa_especial;
	}


	public int getVelocidad() {
		return velocidad;
	}


	public void setVelocidad(int velocidad) {
		this.velocidad = velocidad;
	}


	public long getPromedio() {
		return promedio;
	}


	public void setPromedio(long promedio) {
		this.promedio = promedio;
	}


	public long getDesviacion_tipica() {
		return desviacion_tipica;
	}


	public void setDesviacion_tipica(long desviacion_tipica) {
		this.desviacion_tipica = desviacion_tipica;
	}


	@Override
	public String toString() {
		return " Entrenador=" + entrenador + ", Nombre del pokemon=" + nombre_pokemon + ", ps=" + ps + ", Suma="
				+ suma + ", Ataque=" + ataque + ", Defensa=" + defensa + ", Ataque especial=" + ataque_especial
				+ ", Defensa especial=" + defensa_especial + ", Velocidad=" + velocidad + ", Promedio=" + promedio
				+ ", Desviacion tipica=" + desviacion_tipica ;
	}
	 
	
	
	
	

	
	

}
