package co.edu.unbosque.controller;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;

import javax.imageio.IIOException;

import co.edu.unbosque.model.PokemonDAO;
import co.edu.unbosque.model.PokemonDTO;

public class HiloServidorPc extends Thread {

	private DataInputStream in;
	private DataOutputStream out;
	private String nombre_entrenador;
	private PokemonDAO pokemondao = new PokemonDAO();

	public HiloServidorPc(DataInputStream in, DataOutputStream out, String nombre_entrenador) {
		super();
		this.in = in;
		this.out = out;
		this.nombre_entrenador = nombre_entrenador;

	}

	@Override
	public void run() {

		int opcion;
		File f = new File("poke.txt");
		File f1 = new File("poke1.txt");
		File f2 = new File("poke2.txt");
		File f3 = new File("poke3.txt");

		while (true) {
			try {
				opcion = in.readInt();

				switch (opcion) {

				case 1:

					String nombre_pokemon = in.readUTF();
					int defensa = in.readInt();
					int defensa_especial = in.readInt();
					int ataque = in.readInt();
					int ataque_especial = in.readInt();
					int velocidad = in.readInt();
					int nivel = in.readInt();
					int ps = 3;
					int suma = ataque + defensa + defensa_especial + ataque_especial;
					long promedio = suma / 6;
					long desviacion_tipica = 8;

					int opcion_caja = in.readInt();

					if (opcion_caja == 1) {

						pokemondao.guardarPokemonCaja1(nombre_pokemon, nombre_pokemon, ps, suma, ataque, defensa,
								ataque_especial, defensa_especial, velocidad, promedio, desviacion_tipica);
						pokemondao.escribirDatosCaja1(f1, nombre_pokemon, nombre_pokemon, ps, suma, ataque, defensa,
								ataque_especial, defensa_especial, velocidad, promedio, desviacion_tipica);
						System.out.println("Datos guardados en la caja 1 ");

					} else if (opcion_caja == 2) {
						pokemondao.guardarPokemonCaja2(nombre_pokemon, nombre_pokemon, ps, suma, ataque, defensa,
								ataque_especial, defensa_especial, velocidad, promedio, desviacion_tipica);
						pokemondao.escribirDatosCaja2(f2, nombre_pokemon, nombre_pokemon, ps, suma, ataque, defensa,
								ataque_especial, defensa_especial, velocidad, promedio, desviacion_tipica);
						System.out.println("Datos guardados en la caja 2 ");

					} else if (opcion_caja == 3) {
						pokemondao.guardarPokemonCaja3(nombre_pokemon, nombre_pokemon, ps, suma, ataque, defensa,
								ataque_especial, defensa_especial, velocidad, promedio, desviacion_tipica);
						pokemondao.escribirDatosCaja3(f3, nombre_pokemon, nombre_pokemon, ps, suma, ataque, defensa,
								ataque_especial, defensa_especial, velocidad, promedio, desviacion_tipica);
						System.out.println("Datos guardados en la caja 3");

					} else if (opcion_caja == 4) {

						pokemondao.guardarPokemonBolsillo(nombre_pokemon, nombre_pokemon, ps, suma, ataque, defensa,
								ataque_especial, defensa_especial, velocidad, promedio, desviacion_tipica);
						System.out.println("Pokemon guardado en bolsillo");

					}

					System.out.println(opcion_caja);

					pokemondao.escribirDatosGeneral(f, nombre_entrenador, nombre_pokemon, ps, suma, ataque, defensa,
							ataque_especial, defensa_especial, velocidad, promedio, desviacion_tipica);

					System.out.println(" Entrenador=" + nombre_entrenador + ", Nombre del pokemon=" + nombre_pokemon
							+ ", ps=" + ps + ", Suma=" + suma + ", Ataque=" + ataque + ", Defensa=" + defensa
							+ ", Ataque especial=" + ataque_especial + ", Defensa especial=" + defensa_especial
							+ ", Velocidad=" + velocidad + ", Promedio=" + promedio + ", Desviacion tipica="
							+ desviacion_tipica + "\r\n");

					break;
				case 2:

					String nombrepoke_intercambio = in.readUTF();
					String nombrepoke_intercambio_bolsillo = in.readUTF();
					int intercambio_poke_caja = in.readInt();

					if (intercambio_poke_caja == 1) {
						pokemondao.intercambiarPokemonCajaBolsillo(nombrepoke_intercambio);
						pokemondao.intercambiarPokemonBolsilloCaja(nombrepoke_intercambio_bolsillo);

					} else if (intercambio_poke_caja == 2) {

					} else if (intercambio_poke_caja == 3) {

					}

					break;
				case 3:
					int opcaja = in.readInt();
					String poke_mostrar_1 = "" ;
					
					if (opcaja == 1) {

						for (PokemonDTO pokemon : pokemondao.caja_numero_uno) {

							poke_mostrar_1 = pokemon.toString();
						}
						System.out.println(poke_mostrar_1);
						out.writeUTF(poke_mostrar_1);
						

						
						

					}

				case 4:

					
					String poke_bolsillo1 = pokemondao.bolsillo.get(0).toString();

						out.writeUTF(poke_bolsillo1);

						String vacio1 = "1. Bolsillo vacio";
						out.writeUTF(vacio1);

				

					String poke_bolsillo2 = pokemondao.bolsillo.get(1).toString();

					if (poke_bolsillo2 != null) {

						out.writeUTF(poke_bolsillo2);

					}

					String poke_bolsillo3 = pokemondao.bolsillo.get(2).toString();
					if (poke_bolsillo3 != null) {

						out.writeUTF(poke_bolsillo3);
					}

					String poke_bolsillo4 = pokemondao.bolsillo.get(3).toString();
					if (poke_bolsillo4 != null) {

						out.writeUTF(poke_bolsillo4);
					}

					String poke_bolsillo5 = pokemondao.bolsillo.get(4).toString();
					if (poke_bolsillo5 != null) {

						out.writeUTF(poke_bolsillo5);
					}

					String poke_bolsillo6 = pokemondao.bolsillo.get(5).toString();
					if (poke_bolsillo6 != null) {

						out.writeUTF(poke_bolsillo6);
					}

					String vacio2 = "2. Bolsillo vacio";
					out.writeUTF(vacio2);

					String vacio3 = "3. Bolsillo vacio";
					out.writeUTF(vacio3);

					String vacio4 = "4. Bolsillo vacio";
					out.writeUTF(vacio4);

					String vacio5 = "5. Bolsillo vacio";
					out.writeUTF(vacio5);

					String vacio6 = "6. Bolsillo vacio";
					out.writeUTF(vacio6);
					break;

				case 5:
					String nombre_pokemonn = in.readUTF();
					int opcioncajael = in.readInt();

					if (opcioncajael == 1) {
						pokemondao.liberacionDePokemonCaja1(nombre_pokemonn);
						pokemondao.borarCaja1(nombre_pokemonn, f1);

						System.out.println(nombre_pokemonn + "eliminado");

					}

					if (opcioncajael == 2) {
						pokemondao.liberacionDePokemonCaja2(nombre_pokemonn);
					}

					if (opcioncajael == 3) {
						pokemondao.liberacionDePokemonCaja3(nombre_pokemonn);
					}

				default:

					out.writeUTF("solo numeros del 1 al 4");

				}

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

}
