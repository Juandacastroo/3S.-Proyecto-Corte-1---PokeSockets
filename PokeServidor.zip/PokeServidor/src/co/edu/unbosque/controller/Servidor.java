package co.edu.unbosque.controller;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

import co.edu.unbosque.model.PokemonDAO;
import co.edu.unbosque.model.PokemonDTO;

public class Servidor {
	
	public void iniciarServidor() {
		

		try {
			// se crea el servidor y se coloca el puerto
			ServerSocket server = new ServerSocket(5000);

			// conexi�n del cliente
			Socket sc;

			System.out.println("Servidor iniciado");

			// el while se pone porque siempre va a estar escuchado peticiones del cliente
			while (true) {

				// Espero la conexion del cliente y la acepto
				sc = server.accept();

				// Entrada de informaci�n
				DataInputStream in = new DataInputStream(sc.getInputStream());
				// Salida de informaci�n
				DataOutputStream out = new DataOutputStream(sc.getOutputStream());
				
			
				// recibe el dato del cliente 

				String nombre_entrenador = in.readUTF();
				
				System.out.println(" Creada la conexi� con el entrenador:"+ nombre_entrenador);

				// Inicio el hilo por cada cliente
				HiloServidorPc hilo = new HiloServidorPc(in,  out,  nombre_entrenador);
				hilo.start();
				
				 
				

			}

		} catch (IOException ex) {
			Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
		}

	}

}